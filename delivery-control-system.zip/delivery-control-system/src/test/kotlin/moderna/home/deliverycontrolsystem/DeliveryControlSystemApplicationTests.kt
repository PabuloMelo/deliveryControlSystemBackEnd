package moderna.home.deliverycontrolsystem

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DeliveryControlSystemApplicationTests {

	@Test
	fun contextLoads() {
	}

}
